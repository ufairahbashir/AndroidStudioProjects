
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mobile_skripsi
	 *	@date 		1653923335174
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

public class iphone_11_pro___x___14_activity extends Activity {

	
	private View _bg__iphone_11_pro___x___14_ek2;
	private ImageView v20_ek1;
	private View line_1_ek7;
	private TextView get_it_on_ek7;
	private TextView rp_4__399_000;
	private ImageView logo_tokopedia_1_ek3;
	private ImageView logo_shopee_1_ek3;
	private TextView vivo_v20_ek1;
	private TextView memori_ek3;
	private TextView baterai_ek3;
	private TextView ukuran_ek3;
	private TextView ram_ek3;
	private TextView camera_ek5;
	private TextView _128_gb_ek2;
	private TextView _8_gb_ek3;
	private TextView _64_mp_ek1;
	private TextView _4000_mah;
	private TextView _100_1_cm2_ek1;
	private ImageView rectangle_10;
	private ImageView rectangle_4_ek3;
	private TextView tambah_ulasan_ek6;
	private TextView tambah_ulasan_ek7;
	private ImageView _back_icon_3_ek7;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.iphone_11_pro___x___14);

		
		_bg__iphone_11_pro___x___14_ek2 = (View) findViewById(R.id._bg__iphone_11_pro___x___14_ek2);
		v20_ek1 = (ImageView) findViewById(R.id.v20_ek1);
		line_1_ek7 = (View) findViewById(R.id.line_1_ek7);
		get_it_on_ek7 = (TextView) findViewById(R.id.get_it_on_ek7);
		rp_4__399_000 = (TextView) findViewById(R.id.rp_4__399_000);
		logo_tokopedia_1_ek3 = (ImageView) findViewById(R.id.logo_tokopedia_1_ek3);
		logo_shopee_1_ek3 = (ImageView) findViewById(R.id.logo_shopee_1_ek3);
		vivo_v20_ek1 = (TextView) findViewById(R.id.vivo_v20_ek1);
		memori_ek3 = (TextView) findViewById(R.id.memori_ek3);
		baterai_ek3 = (TextView) findViewById(R.id.baterai_ek3);
		ukuran_ek3 = (TextView) findViewById(R.id.ukuran_ek3);
		ram_ek3 = (TextView) findViewById(R.id.ram_ek3);
		camera_ek5 = (TextView) findViewById(R.id.camera_ek5);
		_128_gb_ek2 = (TextView) findViewById(R.id._128_gb_ek2);
		_8_gb_ek3 = (TextView) findViewById(R.id._8_gb_ek3);
		_64_mp_ek1 = (TextView) findViewById(R.id._64_mp_ek1);
		_4000_mah = (TextView) findViewById(R.id._4000_mah);
		_100_1_cm2_ek1 = (TextView) findViewById(R.id._100_1_cm2_ek1);
		rectangle_10 = (ImageView) findViewById(R.id.rectangle_10);
		rectangle_4_ek3 = (ImageView) findViewById(R.id.rectangle_4_ek3);
		tambah_ulasan_ek6 = (TextView) findViewById(R.id.tambah_ulasan_ek6);
		tambah_ulasan_ek7 = (TextView) findViewById(R.id.tambah_ulasan_ek7);
		_back_icon_3_ek7 = (ImageView) findViewById(R.id._back_icon_3_ek7);
	
		
		_back_icon_3_ek7.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), iphone_11_pro___x___4_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	