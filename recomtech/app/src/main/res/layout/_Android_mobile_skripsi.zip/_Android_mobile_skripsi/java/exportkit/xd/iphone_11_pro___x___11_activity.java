
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mobile_skripsi
	 *	@date 		1653923335174
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

public class iphone_11_pro___x___11_activity extends Activity {

	
	private View _bg__iphone_11_pro___x___11_ek2;
	private ImageView samsung_a73_1_ek1;
	private TextView samsung_a73_ek1;
	private TextView rp_7__799_000;
	private View line_1_ek1;
	private ImageView logo_tokopedia_1;
	private ImageView logo_shopee_1;
	private TextView get_it_on_ek1;
	private TextView memori;
	private TextView baterai;
	private TextView ukuran;
	private TextView ram;
	private TextView camera_ek2;
	private TextView _256_gb;
	private TextView _8_gb;
	private TextView _32_mp;
	private TextView _5000_mah;
	private TextView _108_4_cm2;
	private ImageView rectangle_13;
	private ImageView rectangle_4;
	private TextView tambah_ulasan;
	private TextView tambah_ulasan_ek1;
	private ImageView _back_icon_3_ek5;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.iphone_11_pro___x___11);

		
		_bg__iphone_11_pro___x___11_ek2 = (View) findViewById(R.id._bg__iphone_11_pro___x___11_ek2);
		samsung_a73_1_ek1 = (ImageView) findViewById(R.id.samsung_a73_1_ek1);
		samsung_a73_ek1 = (TextView) findViewById(R.id.samsung_a73_ek1);
		rp_7__799_000 = (TextView) findViewById(R.id.rp_7__799_000);
		line_1_ek1 = (View) findViewById(R.id.line_1_ek1);
		logo_tokopedia_1 = (ImageView) findViewById(R.id.logo_tokopedia_1);
		logo_shopee_1 = (ImageView) findViewById(R.id.logo_shopee_1);
		get_it_on_ek1 = (TextView) findViewById(R.id.get_it_on_ek1);
		memori = (TextView) findViewById(R.id.memori);
		baterai = (TextView) findViewById(R.id.baterai);
		ukuran = (TextView) findViewById(R.id.ukuran);
		ram = (TextView) findViewById(R.id.ram);
		camera_ek2 = (TextView) findViewById(R.id.camera_ek2);
		_256_gb = (TextView) findViewById(R.id._256_gb);
		_8_gb = (TextView) findViewById(R.id._8_gb);
		_32_mp = (TextView) findViewById(R.id._32_mp);
		_5000_mah = (TextView) findViewById(R.id._5000_mah);
		_108_4_cm2 = (TextView) findViewById(R.id._108_4_cm2);
		rectangle_13 = (ImageView) findViewById(R.id.rectangle_13);
		rectangle_4 = (ImageView) findViewById(R.id.rectangle_4);
		tambah_ulasan = (TextView) findViewById(R.id.tambah_ulasan);
		tambah_ulasan_ek1 = (TextView) findViewById(R.id.tambah_ulasan_ek1);
		_back_icon_3_ek5 = (ImageView) findViewById(R.id._back_icon_3_ek5);
	
		
		_back_icon_3_ek5.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), iphone_11_pro___x___3_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	