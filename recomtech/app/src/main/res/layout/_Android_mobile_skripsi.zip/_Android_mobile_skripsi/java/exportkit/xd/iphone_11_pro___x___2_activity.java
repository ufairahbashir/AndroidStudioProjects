
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mobile_skripsi
	 *	@date 		1653923335174
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Intent;

public class iphone_11_pro___x___2_activity extends Activity {

	
	private View _bg__iphone_11_pro___x___2_ek2;
	private TextView smartphone;
	private TextView smartphone_ek1;
	private TextView laptop;
	private TextView laptop_ek1;
	private TextView camera;
	private TextView camera_ek1;
	private ImageView oliver_pecker_honjp8dyism_unsplash_1;
	private ImageView black_samsung_logo_png_21_1_ek1;
	private ImageView samsung_galaxy_a20s_32gb_black_1;
	private View rectangle_2;
	private TextView home;
	private ImageView _logo_menu_1;
	private ImageView logo_vivo_1;
	private ImageView hp_vivo_1;
	private ImageView logo_oppo_1;
	private ImageView hp_oppo_1;
	private ImageView laptop_acer_1;
	private ImageView acer_1;
	private ImageView laptop_asus_1;
	private ImageView asus_logo_1;
	private ImageView logo_nikon_1;
	private ImageView kamera_nikon_1;
	private ImageView kamera_canon_1;
	private ImageView logo_canon_1;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.iphone_11_pro___x___2);

		
		_bg__iphone_11_pro___x___2_ek2 = (View) findViewById(R.id._bg__iphone_11_pro___x___2_ek2);
		smartphone = (TextView) findViewById(R.id.smartphone);
		smartphone_ek1 = (TextView) findViewById(R.id.smartphone_ek1);
		laptop = (TextView) findViewById(R.id.laptop);
		laptop_ek1 = (TextView) findViewById(R.id.laptop_ek1);
		camera = (TextView) findViewById(R.id.camera);
		camera_ek1 = (TextView) findViewById(R.id.camera_ek1);
		oliver_pecker_honjp8dyism_unsplash_1 = (ImageView) findViewById(R.id.oliver_pecker_honjp8dyism_unsplash_1);
		black_samsung_logo_png_21_1_ek1 = (ImageView) findViewById(R.id.black_samsung_logo_png_21_1_ek1);
		samsung_galaxy_a20s_32gb_black_1 = (ImageView) findViewById(R.id.samsung_galaxy_a20s_32gb_black_1);
		rectangle_2 = (View) findViewById(R.id.rectangle_2);
		home = (TextView) findViewById(R.id.home);
		_logo_menu_1 = (ImageView) findViewById(R.id._logo_menu_1);
		logo_vivo_1 = (ImageView) findViewById(R.id.logo_vivo_1);
		hp_vivo_1 = (ImageView) findViewById(R.id.hp_vivo_1);
		logo_oppo_1 = (ImageView) findViewById(R.id.logo_oppo_1);
		hp_oppo_1 = (ImageView) findViewById(R.id.hp_oppo_1);
		laptop_acer_1 = (ImageView) findViewById(R.id.laptop_acer_1);
		acer_1 = (ImageView) findViewById(R.id.acer_1);
		laptop_asus_1 = (ImageView) findViewById(R.id.laptop_asus_1);
		asus_logo_1 = (ImageView) findViewById(R.id.asus_logo_1);
		logo_nikon_1 = (ImageView) findViewById(R.id.logo_nikon_1);
		kamera_nikon_1 = (ImageView) findViewById(R.id.kamera_nikon_1);
		kamera_canon_1 = (ImageView) findViewById(R.id.kamera_canon_1);
		logo_canon_1 = (ImageView) findViewById(R.id.logo_canon_1);
	
		
		_logo_menu_1.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), iphone_11_pro___x___1_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	