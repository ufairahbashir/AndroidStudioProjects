
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mobile_skripsi
	 *	@date 		1653923335174
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

public class iphone_11_pro___x___16_activity extends Activity {

	
	private View _bg__iphone_11_pro___x___16_ek2;
	private ImageView rectangle_10_ek1;
	private ImageView rectangle_4_ek5;
	private TextView tambah_ulasan_ek10;
	private TextView tambah_ulasan_ek11;
	private ImageView oppo_reno_7_z_5g_ek1;
	private View line_1_ek11;
	private TextView get_it_on_ek11;
	private TextView rp_5__999_000_ek2;
	private ImageView logo_tokopedia_1_ek5;
	private ImageView logo_shopee_1_ek5;
	private TextView oppo_reno7_z_5g;
	private TextView memori_ek5;
	private TextView baterai_ek5;
	private TextView ukuran_ek5;
	private TextView ram_ek5;
	private TextView camera_ek7;
	private TextView _128gb;
	private TextView _8_gb_ek4;
	private TextView _64_mp_ek2;
	private TextView _5000_mah_ek3;
	private TextView _99_8_cm2;
	private ImageView _back_icon_3_ek9;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.iphone_11_pro___x___16);

		
		_bg__iphone_11_pro___x___16_ek2 = (View) findViewById(R.id._bg__iphone_11_pro___x___16_ek2);
		rectangle_10_ek1 = (ImageView) findViewById(R.id.rectangle_10_ek1);
		rectangle_4_ek5 = (ImageView) findViewById(R.id.rectangle_4_ek5);
		tambah_ulasan_ek10 = (TextView) findViewById(R.id.tambah_ulasan_ek10);
		tambah_ulasan_ek11 = (TextView) findViewById(R.id.tambah_ulasan_ek11);
		oppo_reno_7_z_5g_ek1 = (ImageView) findViewById(R.id.oppo_reno_7_z_5g_ek1);
		line_1_ek11 = (View) findViewById(R.id.line_1_ek11);
		get_it_on_ek11 = (TextView) findViewById(R.id.get_it_on_ek11);
		rp_5__999_000_ek2 = (TextView) findViewById(R.id.rp_5__999_000_ek2);
		logo_tokopedia_1_ek5 = (ImageView) findViewById(R.id.logo_tokopedia_1_ek5);
		logo_shopee_1_ek5 = (ImageView) findViewById(R.id.logo_shopee_1_ek5);
		oppo_reno7_z_5g = (TextView) findViewById(R.id.oppo_reno7_z_5g);
		memori_ek5 = (TextView) findViewById(R.id.memori_ek5);
		baterai_ek5 = (TextView) findViewById(R.id.baterai_ek5);
		ukuran_ek5 = (TextView) findViewById(R.id.ukuran_ek5);
		ram_ek5 = (TextView) findViewById(R.id.ram_ek5);
		camera_ek7 = (TextView) findViewById(R.id.camera_ek7);
		_128gb = (TextView) findViewById(R.id._128gb);
		_8_gb_ek4 = (TextView) findViewById(R.id._8_gb_ek4);
		_64_mp_ek2 = (TextView) findViewById(R.id._64_mp_ek2);
		_5000_mah_ek3 = (TextView) findViewById(R.id._5000_mah_ek3);
		_99_8_cm2 = (TextView) findViewById(R.id._99_8_cm2);
		_back_icon_3_ek9 = (ImageView) findViewById(R.id._back_icon_3_ek9);
	
		
		_back_icon_3_ek9.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), iphone_11_pro___x___5_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	