
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mobile_skripsi
	 *	@date 		1653923335174
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

public class iphone_11_pro___x___24_activity extends Activity {

	
	private View _bg__iphone_11_pro___x___24_ek2;
	private ImageView zenbook_14_2;
	private TextView asus_zenbook_14_ek1;
	private TextView ukuran_ek10;
	private TextView memory_ek4;
	private TextView storage_ek4;
	private TextView battery_ek4;
	private TextView dimension_ek1;
	private TextView _14_inches;
	private TextView _8_gb_ek8;
	private TextView _256_gb_ssd;
	private TextView _3_cell__50_whrs;
	private TextView _319_x_199_x_15_9_mm;
	private View line_1_ek25;
	private TextView get_it_on_ek29;
	private TextView rp_20__999_000;
	private ImageView logo_tokopedia_1_ek14;
	private ImageView logo_shopee_1_ek14;
	private ImageView rectangle_12_ek2;
	private ImageView rectangle_4_ek13;
	private TextView tambah_ulasan_ek26;
	private TextView tambah_ulasan_ek27;
	private ImageView _back_icon_3_ek17;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.iphone_11_pro___x___24);

		
		_bg__iphone_11_pro___x___24_ek2 = (View) findViewById(R.id._bg__iphone_11_pro___x___24_ek2);
		zenbook_14_2 = (ImageView) findViewById(R.id.zenbook_14_2);
		asus_zenbook_14_ek1 = (TextView) findViewById(R.id.asus_zenbook_14_ek1);
		ukuran_ek10 = (TextView) findViewById(R.id.ukuran_ek10);
		memory_ek4 = (TextView) findViewById(R.id.memory_ek4);
		storage_ek4 = (TextView) findViewById(R.id.storage_ek4);
		battery_ek4 = (TextView) findViewById(R.id.battery_ek4);
		dimension_ek1 = (TextView) findViewById(R.id.dimension_ek1);
		_14_inches = (TextView) findViewById(R.id._14_inches);
		_8_gb_ek8 = (TextView) findViewById(R.id._8_gb_ek8);
		_256_gb_ssd = (TextView) findViewById(R.id._256_gb_ssd);
		_3_cell__50_whrs = (TextView) findViewById(R.id._3_cell__50_whrs);
		_319_x_199_x_15_9_mm = (TextView) findViewById(R.id._319_x_199_x_15_9_mm);
		line_1_ek25 = (View) findViewById(R.id.line_1_ek25);
		get_it_on_ek29 = (TextView) findViewById(R.id.get_it_on_ek29);
		rp_20__999_000 = (TextView) findViewById(R.id.rp_20__999_000);
		logo_tokopedia_1_ek14 = (ImageView) findViewById(R.id.logo_tokopedia_1_ek14);
		logo_shopee_1_ek14 = (ImageView) findViewById(R.id.logo_shopee_1_ek14);
		rectangle_12_ek2 = (ImageView) findViewById(R.id.rectangle_12_ek2);
		rectangle_4_ek13 = (ImageView) findViewById(R.id.rectangle_4_ek13);
		tambah_ulasan_ek26 = (TextView) findViewById(R.id.tambah_ulasan_ek26);
		tambah_ulasan_ek27 = (TextView) findViewById(R.id.tambah_ulasan_ek27);
		_back_icon_3_ek17 = (ImageView) findViewById(R.id._back_icon_3_ek17);
	
		
		_back_icon_3_ek17.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), iphone_11_pro___x___7_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	