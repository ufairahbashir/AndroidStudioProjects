
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mobile_skripsi
	 *	@date 		1653923335174
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

public class iphone_11_pro___x___17_activity extends Activity {

	
	private View _bg__iphone_11_pro___x___17_ek2;
	private ImageView acer_aspire_6;
	private TextView acer_aspire_3_ek2;
	private TextView ukuran_ek6;
	private TextView memory;
	private TextView storage;
	private TextView battery;
	private TextView webcam;
	private TextView _15_6_inches;
	private TextView _8_gb_ek5;
	private TextView _128_ssd;
	private TextView _4810_mah;
	private TextView _640_x_480_webcam;
	private View line_1_ek13;
	private TextView get_it_on_ek13;
	private TextView rp_5__909_000;
	private ImageView logo_tokopedia_1_ek6;
	private ImageView logo_shopee_1_ek6;
	private TextView acer_aspire_3_ek3;
	private View line_1_ek14;
	private ImageView rectangle_9;
	private ImageView rectangle_4_ek6;
	private TextView tambah_ulasan_ek12;
	private TextView tambah_ulasan_ek13;
	private ImageView _back_icon_3_ek10;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.iphone_11_pro___x___17);

		
		_bg__iphone_11_pro___x___17_ek2 = (View) findViewById(R.id._bg__iphone_11_pro___x___17_ek2);
		acer_aspire_6 = (ImageView) findViewById(R.id.acer_aspire_6);
		acer_aspire_3_ek2 = (TextView) findViewById(R.id.acer_aspire_3_ek2);
		ukuran_ek6 = (TextView) findViewById(R.id.ukuran_ek6);
		memory = (TextView) findViewById(R.id.memory);
		storage = (TextView) findViewById(R.id.storage);
		battery = (TextView) findViewById(R.id.battery);
		webcam = (TextView) findViewById(R.id.webcam);
		_15_6_inches = (TextView) findViewById(R.id._15_6_inches);
		_8_gb_ek5 = (TextView) findViewById(R.id._8_gb_ek5);
		_128_ssd = (TextView) findViewById(R.id._128_ssd);
		_4810_mah = (TextView) findViewById(R.id._4810_mah);
		_640_x_480_webcam = (TextView) findViewById(R.id._640_x_480_webcam);
		line_1_ek13 = (View) findViewById(R.id.line_1_ek13);
		get_it_on_ek13 = (TextView) findViewById(R.id.get_it_on_ek13);
		rp_5__909_000 = (TextView) findViewById(R.id.rp_5__909_000);
		logo_tokopedia_1_ek6 = (ImageView) findViewById(R.id.logo_tokopedia_1_ek6);
		logo_shopee_1_ek6 = (ImageView) findViewById(R.id.logo_shopee_1_ek6);
		acer_aspire_3_ek3 = (TextView) findViewById(R.id.acer_aspire_3_ek3);
		line_1_ek14 = (View) findViewById(R.id.line_1_ek14);
		rectangle_9 = (ImageView) findViewById(R.id.rectangle_9);
		rectangle_4_ek6 = (ImageView) findViewById(R.id.rectangle_4_ek6);
		tambah_ulasan_ek12 = (TextView) findViewById(R.id.tambah_ulasan_ek12);
		tambah_ulasan_ek13 = (TextView) findViewById(R.id.tambah_ulasan_ek13);
		_back_icon_3_ek10 = (ImageView) findViewById(R.id._back_icon_3_ek10);
	
		
		_back_icon_3_ek10.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), iphone_11_pro___x___6_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	