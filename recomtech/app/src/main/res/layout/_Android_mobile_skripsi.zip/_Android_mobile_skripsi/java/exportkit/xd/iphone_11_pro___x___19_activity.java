
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mobile_skripsi
	 *	@date 		1653923335174
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

public class iphone_11_pro___x___19_activity extends Activity {

	
	private View _bg__iphone_11_pro___x___19_ek2;
	private ImageView canon_eos_m200_2;
	private TextView canon_eos_m200__mirorrless__ek1;
	private TextView monitor_lcd;
	private TextView iso;
	private TextView pixel;
	private TextView panjang_fokus;
	private TextView resolusi;
	private TextView _3_inches;
	private TextView h_51_200;
	private TextView _25_8;
	private TextView _24_72mm__3x_;
	private TextView _6000_x_4000__l__3984_x_2656__m__2976_x_1984__s1__2400_x_1600__s2__6000_x_4000;
	private ImageView rectangle_11_ek2;
	private ImageView rectangle_4_ek8;
	private TextView tambah_ulasan_ek16;
	private TextView tambah_ulasan_ek17;
	private View line_1_ek18;
	private TextView get_it_on_ek19;
	private TextView rp_8__935_500;
	private ImageView logo_tokopedia_1_ek9;
	private ImageView logo_shopee_1_ek9;
	private ImageView _back_icon_3_ek12;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.iphone_11_pro___x___19);

		
		_bg__iphone_11_pro___x___19_ek2 = (View) findViewById(R.id._bg__iphone_11_pro___x___19_ek2);
		canon_eos_m200_2 = (ImageView) findViewById(R.id.canon_eos_m200_2);
		canon_eos_m200__mirorrless__ek1 = (TextView) findViewById(R.id.canon_eos_m200__mirorrless__ek1);
		monitor_lcd = (TextView) findViewById(R.id.monitor_lcd);
		iso = (TextView) findViewById(R.id.iso);
		pixel = (TextView) findViewById(R.id.pixel);
		panjang_fokus = (TextView) findViewById(R.id.panjang_fokus);
		resolusi = (TextView) findViewById(R.id.resolusi);
		_3_inches = (TextView) findViewById(R.id._3_inches);
		h_51_200 = (TextView) findViewById(R.id.h_51_200);
		_25_8 = (TextView) findViewById(R.id._25_8);
		_24_72mm__3x_ = (TextView) findViewById(R.id._24_72mm__3x_);
		_6000_x_4000__l__3984_x_2656__m__2976_x_1984__s1__2400_x_1600__s2__6000_x_4000 = (TextView) findViewById(R.id._6000_x_4000__l__3984_x_2656__m__2976_x_1984__s1__2400_x_1600__s2__6000_x_4000);
		rectangle_11_ek2 = (ImageView) findViewById(R.id.rectangle_11_ek2);
		rectangle_4_ek8 = (ImageView) findViewById(R.id.rectangle_4_ek8);
		tambah_ulasan_ek16 = (TextView) findViewById(R.id.tambah_ulasan_ek16);
		tambah_ulasan_ek17 = (TextView) findViewById(R.id.tambah_ulasan_ek17);
		line_1_ek18 = (View) findViewById(R.id.line_1_ek18);
		get_it_on_ek19 = (TextView) findViewById(R.id.get_it_on_ek19);
		rp_8__935_500 = (TextView) findViewById(R.id.rp_8__935_500);
		logo_tokopedia_1_ek9 = (ImageView) findViewById(R.id.logo_tokopedia_1_ek9);
		logo_shopee_1_ek9 = (ImageView) findViewById(R.id.logo_shopee_1_ek9);
		_back_icon_3_ek12 = (ImageView) findViewById(R.id._back_icon_3_ek12);
	
		
		_back_icon_3_ek12.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), iphone_11_pro___x___8_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	