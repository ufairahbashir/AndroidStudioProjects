
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mobile_skripsi
	 *	@date 		1653923335174
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

public class iphone_11_pro___x___15_activity extends Activity {

	
	private View _bg__iphone_11_pro___x___15_ek2;
	private ImageView oppo_a16_ek2;
	private View line_1_ek9;
	private TextView get_it_on_ek9;
	private TextView oppo_a16_ek3;
	private TextView memori_ek4;
	private TextView baterai_ek4;
	private TextView ukuran_ek4;
	private TextView ram_ek4;
	private TextView camera_ek6;
	private TextView _256_gb_ek1;
	private TextView _4_gb;
	private TextView _13_mp;
	private TextView _5000_mah_ek2;
	private TextView _102_6_cm2;
	private TextView rp_2__199_000;
	private ImageView logo_tokopedia_1_ek4;
	private ImageView logo_shopee_1_ek4;
	private ImageView rectangle_11_ek1;
	private ImageView rectangle_4_ek4;
	private TextView tambah_ulasan_ek8;
	private TextView tambah_ulasan_ek9;
	private ImageView _back_icon_3_ek8;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.iphone_11_pro___x___15);

		
		_bg__iphone_11_pro___x___15_ek2 = (View) findViewById(R.id._bg__iphone_11_pro___x___15_ek2);
		oppo_a16_ek2 = (ImageView) findViewById(R.id.oppo_a16_ek2);
		line_1_ek9 = (View) findViewById(R.id.line_1_ek9);
		get_it_on_ek9 = (TextView) findViewById(R.id.get_it_on_ek9);
		oppo_a16_ek3 = (TextView) findViewById(R.id.oppo_a16_ek3);
		memori_ek4 = (TextView) findViewById(R.id.memori_ek4);
		baterai_ek4 = (TextView) findViewById(R.id.baterai_ek4);
		ukuran_ek4 = (TextView) findViewById(R.id.ukuran_ek4);
		ram_ek4 = (TextView) findViewById(R.id.ram_ek4);
		camera_ek6 = (TextView) findViewById(R.id.camera_ek6);
		_256_gb_ek1 = (TextView) findViewById(R.id._256_gb_ek1);
		_4_gb = (TextView) findViewById(R.id._4_gb);
		_13_mp = (TextView) findViewById(R.id._13_mp);
		_5000_mah_ek2 = (TextView) findViewById(R.id._5000_mah_ek2);
		_102_6_cm2 = (TextView) findViewById(R.id._102_6_cm2);
		rp_2__199_000 = (TextView) findViewById(R.id.rp_2__199_000);
		logo_tokopedia_1_ek4 = (ImageView) findViewById(R.id.logo_tokopedia_1_ek4);
		logo_shopee_1_ek4 = (ImageView) findViewById(R.id.logo_shopee_1_ek4);
		rectangle_11_ek1 = (ImageView) findViewById(R.id.rectangle_11_ek1);
		rectangle_4_ek4 = (ImageView) findViewById(R.id.rectangle_4_ek4);
		tambah_ulasan_ek8 = (TextView) findViewById(R.id.tambah_ulasan_ek8);
		tambah_ulasan_ek9 = (TextView) findViewById(R.id.tambah_ulasan_ek9);
		_back_icon_3_ek8 = (ImageView) findViewById(R.id._back_icon_3_ek8);
	
		
		_back_icon_3_ek8.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), iphone_11_pro___x___5_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	