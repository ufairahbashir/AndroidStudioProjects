
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mobile_skripsi
	 *	@date 		1653923335174
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

public class iphone_11_pro___x___18_activity extends Activity {

	
	private View _bg__iphone_11_pro___x___18_ek2;
	private ImageView acer_aspire_5_nx_2;
	private TextView acer_aspire_5_ek1;
	private TextView ukuran_ek7;
	private TextView memory_ek1;
	private TextView storage_ek1;
	private TextView battery_ek1;
	private TextView webcam_ek1;
	private TextView _15_6_inches_ek1;
	private TextView _8_gb_ek6;
	private TextView _128_ssd_ek1;
	private TextView _4810_mah_ek1;
	private TextView _640_x_480_webcam_ek1;
	private View line_1_ek15;
	private TextView get_it_on_ek15;
	private TextView rp_5__909_000_ek1;
	private ImageView logo_tokopedia_1_ek7;
	private ImageView logo_shopee_1_ek7;
	private TextView ukuran_ek8;
	private TextView memory_ek2;
	private TextView storage_ek2;
	private TextView battery_ek2;
	private TextView webcam_ek2;
	private TextView _15_6_inches_ek2;
	private TextView _8_gb_ek7;
	private TextView _128_ssd_ek2;
	private TextView _4810_mah_ek2;
	private TextView _640_x_480_webcam_ek2;
	private View line_1_ek16;
	private TextView get_it_on_ek17;
	private TextView rp_5__909_000_ek2;
	private ImageView logo_tokopedia_1_ek8;
	private ImageView logo_shopee_1_ek8;
	private ImageView rectangle_10_ek2;
	private ImageView rectangle_4_ek7;
	private TextView tambah_ulasan_ek14;
	private TextView tambah_ulasan_ek15;
	private ImageView _back_icon_3_ek11;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.iphone_11_pro___x___18);

		
		_bg__iphone_11_pro___x___18_ek2 = (View) findViewById(R.id._bg__iphone_11_pro___x___18_ek2);
		acer_aspire_5_nx_2 = (ImageView) findViewById(R.id.acer_aspire_5_nx_2);
		acer_aspire_5_ek1 = (TextView) findViewById(R.id.acer_aspire_5_ek1);
		ukuran_ek7 = (TextView) findViewById(R.id.ukuran_ek7);
		memory_ek1 = (TextView) findViewById(R.id.memory_ek1);
		storage_ek1 = (TextView) findViewById(R.id.storage_ek1);
		battery_ek1 = (TextView) findViewById(R.id.battery_ek1);
		webcam_ek1 = (TextView) findViewById(R.id.webcam_ek1);
		_15_6_inches_ek1 = (TextView) findViewById(R.id._15_6_inches_ek1);
		_8_gb_ek6 = (TextView) findViewById(R.id._8_gb_ek6);
		_128_ssd_ek1 = (TextView) findViewById(R.id._128_ssd_ek1);
		_4810_mah_ek1 = (TextView) findViewById(R.id._4810_mah_ek1);
		_640_x_480_webcam_ek1 = (TextView) findViewById(R.id._640_x_480_webcam_ek1);
		line_1_ek15 = (View) findViewById(R.id.line_1_ek15);
		get_it_on_ek15 = (TextView) findViewById(R.id.get_it_on_ek15);
		rp_5__909_000_ek1 = (TextView) findViewById(R.id.rp_5__909_000_ek1);
		logo_tokopedia_1_ek7 = (ImageView) findViewById(R.id.logo_tokopedia_1_ek7);
		logo_shopee_1_ek7 = (ImageView) findViewById(R.id.logo_shopee_1_ek7);
		ukuran_ek8 = (TextView) findViewById(R.id.ukuran_ek8);
		memory_ek2 = (TextView) findViewById(R.id.memory_ek2);
		storage_ek2 = (TextView) findViewById(R.id.storage_ek2);
		battery_ek2 = (TextView) findViewById(R.id.battery_ek2);
		webcam_ek2 = (TextView) findViewById(R.id.webcam_ek2);
		_15_6_inches_ek2 = (TextView) findViewById(R.id._15_6_inches_ek2);
		_8_gb_ek7 = (TextView) findViewById(R.id._8_gb_ek7);
		_128_ssd_ek2 = (TextView) findViewById(R.id._128_ssd_ek2);
		_4810_mah_ek2 = (TextView) findViewById(R.id._4810_mah_ek2);
		_640_x_480_webcam_ek2 = (TextView) findViewById(R.id._640_x_480_webcam_ek2);
		line_1_ek16 = (View) findViewById(R.id.line_1_ek16);
		get_it_on_ek17 = (TextView) findViewById(R.id.get_it_on_ek17);
		rp_5__909_000_ek2 = (TextView) findViewById(R.id.rp_5__909_000_ek2);
		logo_tokopedia_1_ek8 = (ImageView) findViewById(R.id.logo_tokopedia_1_ek8);
		logo_shopee_1_ek8 = (ImageView) findViewById(R.id.logo_shopee_1_ek8);
		rectangle_10_ek2 = (ImageView) findViewById(R.id.rectangle_10_ek2);
		rectangle_4_ek7 = (ImageView) findViewById(R.id.rectangle_4_ek7);
		tambah_ulasan_ek14 = (TextView) findViewById(R.id.tambah_ulasan_ek14);
		tambah_ulasan_ek15 = (TextView) findViewById(R.id.tambah_ulasan_ek15);
		_back_icon_3_ek11 = (ImageView) findViewById(R.id._back_icon_3_ek11);
	
		
		_back_icon_3_ek11.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), iphone_11_pro___x___6_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	