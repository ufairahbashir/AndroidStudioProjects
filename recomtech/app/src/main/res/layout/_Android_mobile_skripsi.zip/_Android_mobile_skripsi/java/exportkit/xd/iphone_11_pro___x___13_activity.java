
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mobile_skripsi
	 *	@date 		1653923335174
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

public class iphone_11_pro___x___13_activity extends Activity {

	
	private View _bg__iphone_11_pro___x___13_ek2;
	private ImageView vivo_v23_2;
	private View line_1_ek5;
	private TextView get_it_on_ek5;
	private TextView rp_5__999_000_ek1;
	private ImageView logo_tokopedia_1_ek2;
	private ImageView logo_shopee_1_ek2;
	private TextView vivo_v23_ek1;
	private TextView _128_gb_ek1;
	private TextView _8_gb_ek2;
	private TextView _64_mp;
	private TextView _4200_mah;
	private TextView _100_1_cm2;
	private TextView memori_ek2;
	private TextView baterai_ek2;
	private TextView ukuran_ek2;
	private TextView ram_ek2;
	private TextView camera_ek4;
	private ImageView rectangle_11;
	private ImageView rectangle_4_ek2;
	private TextView tambah_ulasan_ek4;
	private TextView tambah_ulasan_ek5;
	private ImageView _back_icon_3_ek6;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.iphone_11_pro___x___13);

		
		_bg__iphone_11_pro___x___13_ek2 = (View) findViewById(R.id._bg__iphone_11_pro___x___13_ek2);
		vivo_v23_2 = (ImageView) findViewById(R.id.vivo_v23_2);
		line_1_ek5 = (View) findViewById(R.id.line_1_ek5);
		get_it_on_ek5 = (TextView) findViewById(R.id.get_it_on_ek5);
		rp_5__999_000_ek1 = (TextView) findViewById(R.id.rp_5__999_000_ek1);
		logo_tokopedia_1_ek2 = (ImageView) findViewById(R.id.logo_tokopedia_1_ek2);
		logo_shopee_1_ek2 = (ImageView) findViewById(R.id.logo_shopee_1_ek2);
		vivo_v23_ek1 = (TextView) findViewById(R.id.vivo_v23_ek1);
		_128_gb_ek1 = (TextView) findViewById(R.id._128_gb_ek1);
		_8_gb_ek2 = (TextView) findViewById(R.id._8_gb_ek2);
		_64_mp = (TextView) findViewById(R.id._64_mp);
		_4200_mah = (TextView) findViewById(R.id._4200_mah);
		_100_1_cm2 = (TextView) findViewById(R.id._100_1_cm2);
		memori_ek2 = (TextView) findViewById(R.id.memori_ek2);
		baterai_ek2 = (TextView) findViewById(R.id.baterai_ek2);
		ukuran_ek2 = (TextView) findViewById(R.id.ukuran_ek2);
		ram_ek2 = (TextView) findViewById(R.id.ram_ek2);
		camera_ek4 = (TextView) findViewById(R.id.camera_ek4);
		rectangle_11 = (ImageView) findViewById(R.id.rectangle_11);
		rectangle_4_ek2 = (ImageView) findViewById(R.id.rectangle_4_ek2);
		tambah_ulasan_ek4 = (TextView) findViewById(R.id.tambah_ulasan_ek4);
		tambah_ulasan_ek5 = (TextView) findViewById(R.id.tambah_ulasan_ek5);
		_back_icon_3_ek6 = (ImageView) findViewById(R.id._back_icon_3_ek6);
	
		
		_back_icon_3_ek6.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), iphone_11_pro___x___4_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	