
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mobile_skripsi
	 *	@date 		1653923335174
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

public class iphone_11_pro___x___20_activity extends Activity {

	
	private View _bg__iphone_11_pro___x___20_ek2;
	private ImageView canon_eos_m50_mark_ii_2;
	private View line_1_ek19;
	private TextView get_it_on_ek21;
	private TextView rp_8__935_500_ek1;
	private ImageView logo_tokopedia_1_ek10;
	private ImageView logo_shopee_1_ek10;
	private TextView canon_eos_mark_ii_ek1;
	private TextView monitor_lcd_ek1;
	private TextView iso_ek1;
	private TextView pixel_ek1;
	private TextView panjang_fokus_ek1;
	private TextView resolusi_ek1;
	private TextView _3_inches_ek1;
	private TextView h_51_200_ek1;
	private TextView __;
	private TextView _6000_x_4000__l___3984_x_2656__m___2976_x_1984__s1___2400_x_1600__s2___6000_x_4000__raw___c_raw_;
	private ImageView rectangle_12_ek1;
	private ImageView rectangle_4_ek9;
	private TextView tambah_ulasan_ek18;
	private TextView tambah_ulasan_ek19;
	private TextView _25_8_ek1;
	private ImageView _back_icon_3_ek13;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.iphone_11_pro___x___20);

		
		_bg__iphone_11_pro___x___20_ek2 = (View) findViewById(R.id._bg__iphone_11_pro___x___20_ek2);
		canon_eos_m50_mark_ii_2 = (ImageView) findViewById(R.id.canon_eos_m50_mark_ii_2);
		line_1_ek19 = (View) findViewById(R.id.line_1_ek19);
		get_it_on_ek21 = (TextView) findViewById(R.id.get_it_on_ek21);
		rp_8__935_500_ek1 = (TextView) findViewById(R.id.rp_8__935_500_ek1);
		logo_tokopedia_1_ek10 = (ImageView) findViewById(R.id.logo_tokopedia_1_ek10);
		logo_shopee_1_ek10 = (ImageView) findViewById(R.id.logo_shopee_1_ek10);
		canon_eos_mark_ii_ek1 = (TextView) findViewById(R.id.canon_eos_mark_ii_ek1);
		monitor_lcd_ek1 = (TextView) findViewById(R.id.monitor_lcd_ek1);
		iso_ek1 = (TextView) findViewById(R.id.iso_ek1);
		pixel_ek1 = (TextView) findViewById(R.id.pixel_ek1);
		panjang_fokus_ek1 = (TextView) findViewById(R.id.panjang_fokus_ek1);
		resolusi_ek1 = (TextView) findViewById(R.id.resolusi_ek1);
		_3_inches_ek1 = (TextView) findViewById(R.id._3_inches_ek1);
		h_51_200_ek1 = (TextView) findViewById(R.id.h_51_200_ek1);
		__ = (TextView) findViewById(R.id.__);
		_6000_x_4000__l___3984_x_2656__m___2976_x_1984__s1___2400_x_1600__s2___6000_x_4000__raw___c_raw_ = (TextView) findViewById(R.id._6000_x_4000__l___3984_x_2656__m___2976_x_1984__s1___2400_x_1600__s2___6000_x_4000__raw___c_raw_);
		rectangle_12_ek1 = (ImageView) findViewById(R.id.rectangle_12_ek1);
		rectangle_4_ek9 = (ImageView) findViewById(R.id.rectangle_4_ek9);
		tambah_ulasan_ek18 = (TextView) findViewById(R.id.tambah_ulasan_ek18);
		tambah_ulasan_ek19 = (TextView) findViewById(R.id.tambah_ulasan_ek19);
		_25_8_ek1 = (TextView) findViewById(R.id._25_8_ek1);
		_back_icon_3_ek13 = (ImageView) findViewById(R.id._back_icon_3_ek13);
	
		
		_back_icon_3_ek13.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), iphone_11_pro___x___8_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	