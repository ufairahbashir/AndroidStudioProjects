
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mobile_skripsi
	 *	@date 		1653923335174
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

public class iphone_11_pro___x___23_activity extends Activity {

	
	private View _bg__iphone_11_pro___x___23_ek2;
	private ImageView zenbook_pro_dual_2;
	private TextView asus_zenbook_pro_duo_ek1;
	private TextView ukuran_ek9;
	private TextView memory_ek3;
	private TextView storage_ek3;
	private TextView battery_ek3;
	private TextView dimension;
	private TextView _15_6_inches_ek3;
	private TextView _32_gb;
	private TextView _1_tb_hdd;
	private TextView _92whrs;
	private TextView _359_8_x_249_2_x_21_5_mm;
	private View line_1_ek24;
	private TextView get_it_on_ek27;
	private TextView rp_24__499_000;
	private ImageView logo_tokopedia_1_ek13;
	private ImageView logo_shopee_1_ek13;
	private ImageView rectangle_11_ek3;
	private ImageView rectangle_4_ek12;
	private TextView tambah_ulasan_ek24;
	private TextView tambah_ulasan_ek25;
	private ImageView _back_icon_3_ek16;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.iphone_11_pro___x___23);

		
		_bg__iphone_11_pro___x___23_ek2 = (View) findViewById(R.id._bg__iphone_11_pro___x___23_ek2);
		zenbook_pro_dual_2 = (ImageView) findViewById(R.id.zenbook_pro_dual_2);
		asus_zenbook_pro_duo_ek1 = (TextView) findViewById(R.id.asus_zenbook_pro_duo_ek1);
		ukuran_ek9 = (TextView) findViewById(R.id.ukuran_ek9);
		memory_ek3 = (TextView) findViewById(R.id.memory_ek3);
		storage_ek3 = (TextView) findViewById(R.id.storage_ek3);
		battery_ek3 = (TextView) findViewById(R.id.battery_ek3);
		dimension = (TextView) findViewById(R.id.dimension);
		_15_6_inches_ek3 = (TextView) findViewById(R.id._15_6_inches_ek3);
		_32_gb = (TextView) findViewById(R.id._32_gb);
		_1_tb_hdd = (TextView) findViewById(R.id._1_tb_hdd);
		_92whrs = (TextView) findViewById(R.id._92whrs);
		_359_8_x_249_2_x_21_5_mm = (TextView) findViewById(R.id._359_8_x_249_2_x_21_5_mm);
		line_1_ek24 = (View) findViewById(R.id.line_1_ek24);
		get_it_on_ek27 = (TextView) findViewById(R.id.get_it_on_ek27);
		rp_24__499_000 = (TextView) findViewById(R.id.rp_24__499_000);
		logo_tokopedia_1_ek13 = (ImageView) findViewById(R.id.logo_tokopedia_1_ek13);
		logo_shopee_1_ek13 = (ImageView) findViewById(R.id.logo_shopee_1_ek13);
		rectangle_11_ek3 = (ImageView) findViewById(R.id.rectangle_11_ek3);
		rectangle_4_ek12 = (ImageView) findViewById(R.id.rectangle_4_ek12);
		tambah_ulasan_ek24 = (TextView) findViewById(R.id.tambah_ulasan_ek24);
		tambah_ulasan_ek25 = (TextView) findViewById(R.id.tambah_ulasan_ek25);
		_back_icon_3_ek16 = (ImageView) findViewById(R.id._back_icon_3_ek16);
	
		
		_back_icon_3_ek16.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), iphone_11_pro___x___7_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	