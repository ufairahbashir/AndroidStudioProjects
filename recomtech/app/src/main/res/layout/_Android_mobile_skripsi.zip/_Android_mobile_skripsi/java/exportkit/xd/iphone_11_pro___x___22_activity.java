
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mobile_skripsi
	 *	@date 		1653923335174
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

public class iphone_11_pro___x___22_activity extends Activity {

	
	private View _bg__iphone_11_pro___x___22_ek2;
	private ImageView nikon_dslr_d5100_2;
	private View line_1_ek22;
	private TextView get_it_on_ek25;
	private TextView rp_8__935_500_ek3;
	private ImageView logo_tokopedia_1_ek12;
	private ImageView logo_shopee_1_ek12;
	private TextView nikon_d5100_ek1;
	private TextView monitor_lcd_ek3;
	private TextView iso_ek3;
	private TextView ukuran_foto_ek1;
	private TextView ukuran_body_ek1;
	private TextView sensor_ek1;
	private TextView _3_inches_ek3;
	private TextView _100_to_6_400;
	private TextView _4_928_x_3_264px;
	private TextView _12_70_x_9_65_x_7_87_cm;
	private TextView _23_6_x_15_6_mm;
	private ImageView rectangle_14;
	private ImageView rectangle_4_ek11;
	private TextView tambah_ulasan_ek22;
	private TextView tambah_ulasan_ek23;
	private ImageView _back_icon_3_ek15;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.iphone_11_pro___x___22);

		
		_bg__iphone_11_pro___x___22_ek2 = (View) findViewById(R.id._bg__iphone_11_pro___x___22_ek2);
		nikon_dslr_d5100_2 = (ImageView) findViewById(R.id.nikon_dslr_d5100_2);
		line_1_ek22 = (View) findViewById(R.id.line_1_ek22);
		get_it_on_ek25 = (TextView) findViewById(R.id.get_it_on_ek25);
		rp_8__935_500_ek3 = (TextView) findViewById(R.id.rp_8__935_500_ek3);
		logo_tokopedia_1_ek12 = (ImageView) findViewById(R.id.logo_tokopedia_1_ek12);
		logo_shopee_1_ek12 = (ImageView) findViewById(R.id.logo_shopee_1_ek12);
		nikon_d5100_ek1 = (TextView) findViewById(R.id.nikon_d5100_ek1);
		monitor_lcd_ek3 = (TextView) findViewById(R.id.monitor_lcd_ek3);
		iso_ek3 = (TextView) findViewById(R.id.iso_ek3);
		ukuran_foto_ek1 = (TextView) findViewById(R.id.ukuran_foto_ek1);
		ukuran_body_ek1 = (TextView) findViewById(R.id.ukuran_body_ek1);
		sensor_ek1 = (TextView) findViewById(R.id.sensor_ek1);
		_3_inches_ek3 = (TextView) findViewById(R.id._3_inches_ek3);
		_100_to_6_400 = (TextView) findViewById(R.id._100_to_6_400);
		_4_928_x_3_264px = (TextView) findViewById(R.id._4_928_x_3_264px);
		_12_70_x_9_65_x_7_87_cm = (TextView) findViewById(R.id._12_70_x_9_65_x_7_87_cm);
		_23_6_x_15_6_mm = (TextView) findViewById(R.id._23_6_x_15_6_mm);
		rectangle_14 = (ImageView) findViewById(R.id.rectangle_14);
		rectangle_4_ek11 = (ImageView) findViewById(R.id.rectangle_4_ek11);
		tambah_ulasan_ek22 = (TextView) findViewById(R.id.tambah_ulasan_ek22);
		tambah_ulasan_ek23 = (TextView) findViewById(R.id.tambah_ulasan_ek23);
		_back_icon_3_ek15 = (ImageView) findViewById(R.id._back_icon_3_ek15);
	
		
		_back_icon_3_ek15.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), iphone_11_pro___x___9_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	