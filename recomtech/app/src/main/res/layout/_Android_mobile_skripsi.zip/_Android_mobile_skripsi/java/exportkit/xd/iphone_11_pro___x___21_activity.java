
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mobile_skripsi
	 *	@date 		1653923335174
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

public class iphone_11_pro___x___21_activity extends Activity {

	
	private View _bg__iphone_11_pro___x___21_ek2;
	private ImageView nikon_dslr_d3500_2;
	private TextView nikon_d3500_ek1;
	private View line_1_ek21;
	private TextView get_it_on_ek23;
	private TextView rp_8__935_500_ek2;
	private ImageView logo_tokopedia_1_ek11;
	private ImageView logo_shopee_1_ek11;
	private TextView monitor_lcd_ek2;
	private TextView _3_inches_ek2;
	private TextView _100_to_25_600;
	private TextView _6_000_x_4_000px;
	private TextView _124_x_97_x_69_5mm;
	private TextView _24_2mp_aps_c_cmos_4__23_5_x_15_6mm;
	private TextView iso_ek2;
	private TextView ukuran_foto;
	private TextView ukuran_body;
	private TextView sensor;
	private ImageView rectangle_13_ek1;
	private ImageView rectangle_4_ek10;
	private TextView tambah_ulasan_ek20;
	private TextView tambah_ulasan_ek21;
	private ImageView _back_icon_3_ek14;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.iphone_11_pro___x___21);

		
		_bg__iphone_11_pro___x___21_ek2 = (View) findViewById(R.id._bg__iphone_11_pro___x___21_ek2);
		nikon_dslr_d3500_2 = (ImageView) findViewById(R.id.nikon_dslr_d3500_2);
		nikon_d3500_ek1 = (TextView) findViewById(R.id.nikon_d3500_ek1);
		line_1_ek21 = (View) findViewById(R.id.line_1_ek21);
		get_it_on_ek23 = (TextView) findViewById(R.id.get_it_on_ek23);
		rp_8__935_500_ek2 = (TextView) findViewById(R.id.rp_8__935_500_ek2);
		logo_tokopedia_1_ek11 = (ImageView) findViewById(R.id.logo_tokopedia_1_ek11);
		logo_shopee_1_ek11 = (ImageView) findViewById(R.id.logo_shopee_1_ek11);
		monitor_lcd_ek2 = (TextView) findViewById(R.id.monitor_lcd_ek2);
		_3_inches_ek2 = (TextView) findViewById(R.id._3_inches_ek2);
		_100_to_25_600 = (TextView) findViewById(R.id._100_to_25_600);
		_6_000_x_4_000px = (TextView) findViewById(R.id._6_000_x_4_000px);
		_124_x_97_x_69_5mm = (TextView) findViewById(R.id._124_x_97_x_69_5mm);
		_24_2mp_aps_c_cmos_4__23_5_x_15_6mm = (TextView) findViewById(R.id._24_2mp_aps_c_cmos_4__23_5_x_15_6mm);
		iso_ek2 = (TextView) findViewById(R.id.iso_ek2);
		ukuran_foto = (TextView) findViewById(R.id.ukuran_foto);
		ukuran_body = (TextView) findViewById(R.id.ukuran_body);
		sensor = (TextView) findViewById(R.id.sensor);
		rectangle_13_ek1 = (ImageView) findViewById(R.id.rectangle_13_ek1);
		rectangle_4_ek10 = (ImageView) findViewById(R.id.rectangle_4_ek10);
		tambah_ulasan_ek20 = (TextView) findViewById(R.id.tambah_ulasan_ek20);
		tambah_ulasan_ek21 = (TextView) findViewById(R.id.tambah_ulasan_ek21);
		_back_icon_3_ek14 = (ImageView) findViewById(R.id._back_icon_3_ek14);
	
		
		_back_icon_3_ek14.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), iphone_11_pro___x___9_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	